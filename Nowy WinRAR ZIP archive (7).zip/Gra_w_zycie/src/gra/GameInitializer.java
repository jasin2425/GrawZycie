package gra;

import gra.organizm.Organizm;
import gra.organizm.zwierze.*;
import gra.organizm.roslina.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Random;

public class GameInitializer {
    private JFrame startFrame;

    public void pokazEkranStartowy() {
        startFrame = new JFrame("Gra o Życie - Ekran Startowy");
        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.setSize(300, 150);
        startFrame.setResizable(false); 
        startFrame.setLayout(new GridLayout(3, 1));

        JButton nowaGraButton = new JButton("Nowa Gra");
        nowaGraButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                uruchomNowaGre();
            }
        });

        JButton wczytajGreButton = new JButton("Wczytaj Grę");
        wczytajGreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                wczytajGre();
            }
        });

        startFrame.add(nowaGraButton);
        startFrame.add(wczytajGreButton);
        startFrame.setLocationRelativeTo(null);
        startFrame.setVisible(true);
    }

    private void uruchomNowaGre() {
        JPanel panel = new JPanel(new GridLayout(2, 2));
        JTextField szerokoscField = new JTextField();
        JTextField wysokoscField = new JTextField();
        panel.add(new JLabel("Szerokość:"));
        panel.add(szerokoscField);
        panel.add(new JLabel("Wysokość:"));
        panel.add(wysokoscField);
        int result = JOptionPane.showConfirmDialog(null, panel, "Podaj wymiary mapy", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                int szerokosc = Integer.parseInt(szerokoscField.getText());
                int wysokosc = Integer.parseInt(wysokoscField.getText());
                startFrame.dispose();
                Swiat swiat = new Swiat(szerokosc, wysokosc);
                dodajOrganizmy(swiat, szerokosc, wysokosc);
                uruchomGre(swiat);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Nieprawidłowe wymiary", "Błąd", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void wczytajGre() {
        startFrame.dispose();
        Swiat swiat = new Swiat(20, 20);
        List<Organizm> organizmy = Main.bazoweOrganizmy(swiat);
        swiat.wczytaj(organizmy);
        uruchomGre(swiat);
    }

    private void uruchomGre(Swiat swiat) {
        Main mainFrame = new Main(swiat);
        for (Organizm organizm : swiat.pobierzOrganizmy()) {
            if (organizm instanceof Czlowiek) {
                mainFrame.addKeyListener((Czlowiek) organizm);
                break;
            }
        }
        mainFrame.setFocusable(true);
        mainFrame.requestFocusInWindow();
    }

    private void dodajOrganizmy(Swiat swiat, int szerokosc, int wysokosc) {
        Random rand = new Random();

        Organizm[] organizmy = {
            new Wilk(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Owca(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Owca(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Czlowiek(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Antylopa(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Lis(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Zolw(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Trawa(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Guarana(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Mlecz(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat),
            new Barszcz(rand.nextInt(szerokosc), rand.nextInt(wysokosc), swiat)
        };

        for (Organizm organizm : organizmy) {
            swiat.dodajOrganizm(organizm);
        }
    }
}
