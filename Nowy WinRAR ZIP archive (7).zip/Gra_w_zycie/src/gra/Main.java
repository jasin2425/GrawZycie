package gra;

import gra.organizm.*;
import gra.organizm.roslina.*;
import gra.organizm.zwierze.*;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Main extends JFrame {
    private Plansza plansza;

    public Main(Swiat swiat) {
        this.plansza = new Plansza(swiat.pobierzOrganizmy(), swiat.getSzerokosc(), swiat.getWysokosc(), swiat);

        setTitle("Gra o Życie");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());

        JButton nextTurnButton = new JButton("Nowa Tura");
        nextTurnButton.addActionListener(e -> {
            nextTurnButton.setEnabled(false);
            new SwingWorker<Void, Void>() {
                @Override
                protected Void doInBackground() throws Exception {
                    swiat.wykonajTure(plansza);
                    swiat.zapis();
                    return null;
                }

                @Override
                protected void done() {
                    nextTurnButton.setEnabled(true);
                }
            }.execute();
        });

        add(plansza, BorderLayout.CENTER);
        add(nextTurnButton, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static List<Organizm> bazoweOrganizmy(Swiat swiat) {
        List<Organizm> bazowe = new ArrayList<>();
        bazowe.add(new Wilk(0, 0, swiat));
        bazowe.add(new Owca(0, 0, swiat));
        bazowe.add(new Czlowiek(0, 0, swiat));
        bazowe.add(new Lis(0, 0, swiat));
        bazowe.add(new Antylopa(0, 0, swiat));
        bazowe.add(new Zolw(0, 0, swiat));
        bazowe.add(new Trawa(0, 0, swiat));
        bazowe.add(new Guarana(0, 0, swiat));
        bazowe.add(new Mlecz(0, 0, swiat));
        bazowe.add(new Barszcz(0, 0, swiat));
        return bazowe;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameInitializer initializer = new GameInitializer();
            initializer.pokazEkranStartowy();
        });
    }
}
