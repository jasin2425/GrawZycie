package gra;

import gra.organizm.Organizm;
import gra.organizm.zwierze.*;
import gra.organizm.roslina.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class Plansza extends JPanel {
    private List<Organizm> organizmy;
    private int cellSize = 20;
    public Plansza(List<Organizm> organizmy, int szerokosc, int wysokosc, Swiat swiat) {
        this.organizmy = organizmy;
        setPreferredSize(new Dimension(szerokosc * cellSize, wysokosc * cellSize));
        setBackground(Color.WHITE);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int x = e.getX() / cellSize;
                int y = e.getY() / cellSize;

                if (swiat.czyPolePuste(x, y)) {
                    String[] options = {"Wilk", "Owca", "Antylopa", "Lis", "Zolw", "Guarana", "Mlecz", "Barszcz"};
                    String wybor = (String) JOptionPane.showInputDialog(null, "Wybierz organizm", "Dodaj Organizm",
                            JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

                    if (wybor != null) {
                        Organizm nowyOrganizm = null;
                        switch (wybor) {
                            case "Wilk":
                                nowyOrganizm = new Wilk(x, y, swiat);
                                break;
                            case "Owca":
                                nowyOrganizm = new Owca(x, y, swiat);
                                break;
                            case "Antylopa":
                                nowyOrganizm = new Antylopa(x, y, swiat);
                                break;
                            case "Lis":
                                nowyOrganizm = new Lis(x, y, swiat);
                                break;
                            case "Zolw":
                                nowyOrganizm = new Zolw(x, y, swiat);
                                break;
                            case "Guarana":
                                nowyOrganizm = new Guarana(x, y, swiat);
                                break;
                            case "Mlecz":
                                nowyOrganizm = new Mlecz(x, y, swiat);
                                break;
                            case "Barszcz":
                                nowyOrganizm = new Barszcz(x, y, swiat);
                                break;
                        }

                        if (nowyOrganizm != null) {
                            swiat.dodajOrganizm(nowyOrganizm);
                            repaint();
                        }
                    }
                }
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawGrid(g);
        drawOrganizmy(g);
    }

    private void drawGrid(Graphics g) {
        g.setColor(Color.LIGHT_GRAY);
        for (int i = 0; i < getWidth(); i += cellSize) {
            g.drawLine(i, 0, i, getHeight());
        }
        for (int i = 0; i < getHeight(); i += cellSize) {
            g.drawLine(0, i, getWidth(), i);
        }
    }

    private void drawOrganizmy(Graphics g) {
        for (Organizm organizm : organizmy) {
            organizm.rysowanie(g, cellSize);
        }
    }
}
