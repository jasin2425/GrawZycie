package gra;

import java.util.*;
import java.io.*;
import javax.swing.JPanel;
import gra.organizm.Organizm;
import gra.organizm.zwierze.Czlowiek;

public class Swiat {
    private int szerokosc, wysokosc;
    private List<Organizm> organizmy;

    public Swiat(int szerokosc, int wysokosc) {
        this.szerokosc = szerokosc;
        this.wysokosc = wysokosc;
        this.organizmy = new ArrayList<>();
    }

    public int getSzerokosc() {
        return szerokosc;
    }

    public int getWysokosc() {
        return wysokosc;
    }

    public boolean czyPolePuste(int x, int y) {
        for (Organizm o : organizmy) {
            if (o.getX() == x && o.getY() == y) {
                return false;
            }
        }
        return true;
    }

    public void wykonajTure(JPanel panel) throws InterruptedException {
        List<Organizm> kopiaOrganizmy = new ArrayList<>(organizmy);
        kopiaOrganizmy.sort(Comparator.comparingInt(Organizm::getInicjatywa).reversed());


        for (Organizm organizm : kopiaOrganizmy) {
            if (organizm.getSila() > -10) {
                System.out.println("Ruch gracza: " + organizm.getGatunek());
                organizm.akcja();
                panel.repaint();
                Thread.sleep(500); 
            }
        }

        zapis();
    }

    public void zapis() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("stangry.txt"))) {
            writer.println(szerokosc + " " + wysokosc + " " + organizmy.size());
            for (Organizm organizm : organizmy) {
                if (organizm != null && organizm.getSila() > -2) {
                    writer.print(organizm.getGatunek() + " " + organizm.getX() + " " + organizm.getY() + " " + organizm.getSila());
                    if (organizm instanceof Czlowiek) {
                        Czlowiek czlowiek = (Czlowiek) organizm;
                        writer.print(" " + (czlowiek.isCzyUmiejetnosc() ? 1 : 0) + " " + czlowiek.getPozostaleTuryUmiejetnosci());
                    }
                    writer.println();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void wczytaj(List<Organizm> bazowe) {
        try (Scanner scanner = new Scanner(new File("stangry.txt"))) {
            szerokosc = scanner.nextInt();
            wysokosc = scanner.nextInt();
            int ileOrg = scanner.nextInt();

            for (int i = 0; i < ileOrg; i++) {
                char gatunek = scanner.next().charAt(0);
                int x = scanner.nextInt();
                int y = scanner.nextInt();
                int sila = scanner.nextInt();
                int czyUmiejetnosc = 0;
                int pozostaleTuryUmiejetnosci = 0;

                if (gatunek == 'C') {
                    czyUmiejetnosc = scanner.nextInt();
                    pozostaleTuryUmiejetnosci = scanner.nextInt();
                }

                for (Organizm organizm : bazowe) {
                    if (organizm.getGatunek() == gatunek) {
                        Organizm nowy = organizm.nowyOrganizm(x, y, this);
                        nowy.ustawSile(sila);
                        if (nowy instanceof Czlowiek) {
                            Czlowiek czlowiek = (Czlowiek) nowy;
                            czlowiek.setCzyUmiejetnosc(czyUmiejetnosc == 1);
                            czlowiek.setPozostaleTuryUmiejetnosci(pozostaleTuryUmiejetnosci);
                        }
                        dodajOrganizm(nowy);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Organizm getOrganizm(int x, int y) {
        for (Organizm o : organizmy) {
            if (o.getX() == x && o.getY() == y) {
                return o;
            }
        }
        return null;
    }

    public void usunOrganizm(Organizm organizm) {
        organizmy.remove(organizm);
    }

    public void ustawOrganizmy(List<Organizm> noweOrganizmy) {
        organizmy = noweOrganizmy;
    }

    public List<Organizm> pobierzOrganizmy() {
        return organizmy;
    }

    public void dodajOrganizm(Organizm nowyOrganizm) {
        organizmy.add(nowyOrganizm);
    }
}
