package gra.organizm;

import gra.Swiat;
import java.util.List;
import java.awt.Font;
import java.awt.Graphics;
public abstract class Organizm {
    protected int sila;
    protected int inicjatywa;
    protected Pozycja pozycja;
    protected Swiat swiat;

    public Organizm(int x, int y, Swiat swiat) {
        this.pozycja = new Pozycja(x, y);
        this.swiat = swiat;
    }

    public Organizm(int x, int y) {
        this.pozycja = new Pozycja(x, y);
    }

    public int getSila() {
        return sila;
    }

    public int getInicjatywa() {
        return inicjatywa;
    }

    public int getX() {
        return pozycja.x;
    }

    public int getY() {
        return pozycja.y;
    }

    public void kolizja(Organizm organizm) {
        List<Organizm> kopiaOrganizmow = getSwiat().pobierzOrganizmy();

        if (organizm.getGatunek() != getGatunek()) {
            if (organizm.getSila() >= getSila()) {
                System.out.println("Kolizja! " + organizm.getGatunek() + " pokonuje " + getGatunek());
                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                getSwiat().usunOrganizm(this);
            } else {
                System.out.println("Kolizja! " + getGatunek() + " pokonuje " + organizm.getGatunek());
                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                getSwiat().usunOrganizm(organizm);
            }
        } else {
            int newX = pozycja.x;
            int newY = pozycja.y - 1;
            if (newY < 0) {
                newY = pozycja.y + 1;
            }
            System.out.println("Kolizja! " + getGatunek() + " tworzy nowy " + organizm.getGatunek());

            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            Organizm nowy = nowyOrganizm(newX, newY, swiat);
            kopiaOrganizmow.add(nowy);
            getSwiat().ustawOrganizmy(kopiaOrganizmow);
        }
    }

    public void ustawSile(int nowaSila) {
        sila = nowaSila;
    }

    public void setX(int newX) {
        pozycja.x = newX;
    }

    public void setY(int newY) {
        pozycja.y = newY;
    }

    public Swiat getSwiat() {
        return swiat;
    }

    public abstract void akcja();
    public abstract void rysowanie(Graphics g, int cellSize);
    public abstract boolean czyOdbilAtak(Organizm atakujacy);
    public abstract Organizm nowyOrganizm(int x, int y, Swiat swiat);
    public abstract char getGatunek();
}
