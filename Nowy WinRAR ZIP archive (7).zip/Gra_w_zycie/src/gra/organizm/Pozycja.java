package gra.organizm;

public class Pozycja {
    public int x, y;

    public Pozycja(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
