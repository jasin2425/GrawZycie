package gra.organizm.roslina;

import gra.Swiat;
import gra.organizm.Organizm;
import gra.organizm.zwierze.Zwierze;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;
import java.util.List;
import java.util.Random;

public class Barszcz extends Roslina {

    public Barszcz(int x, int y, Swiat swiat) {
        super(x, y, swiat);
        this.sila = 10;
        this.inicjatywa = 0;
    }

    @Override
    public void akcja() {
        boolean wychodzizamape = true;
        boolean pustepole = false;
        int noweX = pozycja.x;
        int noweY = pozycja.y;
        niszczenie(noweX, noweY);
        int czy_nowa = new Random().nextInt();
        if (czy_nowa % 4 == 0) {
            while (wychodzizamape == true && pustepole == false) {
                noweX = pozycja.x;
                noweY = pozycja.y;
                int losowa = new Random().nextInt();

                if (losowa % 4 == 0) {
                    if (getY() != 0) {
                        wychodzizamape = false;
                        noweY--;
                    } else
                        wychodzizamape = true;
                } else if (losowa % 4 == 1) {
                    if (getY() != getSwiat().getWysokosc() - 1) {
                        wychodzizamape = false;
                        noweY++;
                    } else
                        wychodzizamape = true;
                } else if (losowa % 4 == 2) {
                    if (getX() != getSwiat().getSzerokosc() - 1) {
                        wychodzizamape = false;
                        noweX++;
                    } else
                        wychodzizamape = true;
                } else if (losowa % 4 == 3) {
                    if (getX() != 0) {
                        wychodzizamape = false;
                        noweX--;
                    } else
                        wychodzizamape = true;
                }
            }
            if (swiat.czyPolePuste(noweX, noweY) == true)
                pustepole = true;
            if (swiat.czyPolePuste(noweX, noweY) == true) {
                List<Organizm> kopiaOrganizmow = getSwiat().pobierzOrganizmy();  

                niszczenie(noweX, noweY);

                Organizm newOrganizm = nowyOrganizm(noweX, noweY, swiat);
                kopiaOrganizmow.add(newOrganizm);
                getSwiat().ustawOrganizmy(kopiaOrganizmow);
            }
        }
    }

    private void niszczenie(int x, int y) {
        int[][] directions = {{0, 1}, {0, -1}, {-1, 0}, {1, 0}};
        for (int[] dir : directions) {
            int newX = x + dir[0];
            int newY = y + dir[1];
            if (!swiat.czyPolePuste(newX, newY) && swiat.getOrganizm(newX, newY).getGatunek() != 'B') {
                Organizm zwierzak = swiat.getOrganizm(newX, newY);
                if (zwierzak != null) {
                    if (zwierzak instanceof Zwierze) {
                        System.out.println("Kolizja! " + getGatunek() + " pokonuje " + zwierzak.getGatunek());
                        swiat.usunOrganizm(zwierzak);
                    }
                }
            }
        }
    }

    @Override
    public void rysowanie(Graphics g, int cellSize) {
        int fontSize = cellSize - 6;
        g.setFont(new Font("Segoe UI Emoji", Font.PLAIN, fontSize));
        g.setColor(Color.GREEN);
        g.drawString("\uD83C\uDF35", getX() * cellSize, getY() * cellSize + cellSize - 5);
    }

    @Override
    public char getGatunek() {
        return 'B';
    }

    @Override
    public Organizm nowyOrganizm(int x, int y, Swiat swiat) {
        return new Barszcz(x, y, swiat);
    }
}
