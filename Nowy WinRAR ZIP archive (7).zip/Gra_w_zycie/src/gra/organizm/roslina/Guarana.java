package gra.organizm.roslina;

import gra.Swiat;
import gra.organizm.Organizm;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;
import java.util.List;

public class Guarana extends Roslina {
    public Guarana(int x, int y, Swiat swiat) {
        super(x, y, swiat);
        this.sila = 0;
        this.inicjatywa = 0;
    }

    @Override
    public void akcja() {
        boolean wychodzizamape = true;
        boolean pustepole = false;
        int noweX = getX();
        int noweY = getY();
        int czy_nowa = (int) (Math.random() * 4);
        if (czy_nowa == 0) {
            while (wychodzizamape && !pustepole) {
                noweX = getX();
                noweY = getY();
                int losowa = (int) (Math.random() * 4);

                if (losowa == 0) {
                    if (getY() != 0) {
                        wychodzizamape = false;
                        noweY--;
                    } else {
                        wychodzizamape = true;
                    }
                } else if (losowa == 1) {
                    if (getY() != getSwiat().getWysokosc() - 1) {
                        wychodzizamape = false;
                        noweY++;
                    } else {
                        wychodzizamape = true;
                    }
                } else if (losowa == 2) {
                    if (getX() != getSwiat().getSzerokosc() - 1) {
                        wychodzizamape = false;
                        noweX++;
                    } else {
                        wychodzizamape = true;
                    }
                } else if (losowa == 3) {
                    if (getX() != 0) {
                        wychodzizamape = false;
                        noweX--;
                    } else {
                        wychodzizamape = true;
                    }
                }
            }
            if (getSwiat().czyPolePuste(noweX, noweY)) {
                pustepole = true;
            }
            if (pustepole) {
                List<Organizm> kopiaOrganizmow = getSwiat().pobierzOrganizmy();
                Organizm nowyOrganizm = nowyOrganizm(noweX, noweY, getSwiat());
                kopiaOrganizmow.add(nowyOrganizm);
                getSwiat().ustawOrganizmy(kopiaOrganizmow);
            }
        }
    }

    @Override
    public void kolizja(Organizm organizm) {
        List<Organizm> kopiaOrganizmow = getSwiat().pobierzOrganizmy();
        System.out.println("Kolizja!");

        if (organizm.getSila() > getSila()) {
            System.out.println("Kolizja! " + organizm.getGatunek() + " pokonuje " + getGatunek());
            organizm.ustawSile(organizm.getSila() + 3);
            System.out.println("Guarana daje bonus +3 sily organizmowi " + organizm.getGatunek() + " " + organizm.getSila());
            getSwiat().usunOrganizm(this);
        } else {
            System.out.println("Kolizja! " + getGatunek() + " pokonuje " + organizm.getGatunek());
            getSwiat().usunOrganizm(organizm);
        }
    }

    @Override
    public void rysowanie(Graphics g, int cellSize) {
        int fontSize = cellSize - 6;
        g.setFont(new Font("Segoe UI Emoji", Font.PLAIN, fontSize));
        g.setColor(new Color(199, 18, 72)); 
        g.drawString("\uD83C\uDF47", getX() * cellSize-1, getY() * cellSize + cellSize-5);
    }

    @Override
    public char getGatunek() {
        return 'G';
    }

    @Override
    public Organizm nowyOrganizm(int x, int y, Swiat swiat) {
        return new Guarana(x, y, swiat);
    }
}
