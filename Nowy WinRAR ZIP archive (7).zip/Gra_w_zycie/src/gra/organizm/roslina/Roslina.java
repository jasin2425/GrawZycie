package gra.organizm.roslina;

import gra.Swiat;
import gra.organizm.Organizm;

import java.awt.Graphics;
import java.util.List;
import java.util.Random;

public abstract class Roslina extends Organizm {
    public Roslina(int x, int y, Swiat swiat) {
        super(x, y, swiat);
    }

    @Override
    public void akcja() {
        Random rand = new Random();
        if (rand.nextInt(4) == 0) {  
            boolean wychodzizamape = true;
            boolean pustepole = false;
            int noweX = getX();
            int noweY = getY();

            while (wychodzizamape) {
                noweX = getX();
                noweY = getY();
                int losowa = rand.nextInt(4);

                if (losowa == 0 && getY() != 0) {
                    noweY--;
                    wychodzizamape = false;
                } else if (losowa == 1 && getY() != getSwiat().getWysokosc() - 1) {
                    noweY++;
                    wychodzizamape = false;
                } else if (losowa == 2 && getX() != getSwiat().getSzerokosc() - 1) {
                    noweX++;
                    wychodzizamape = false;
                } else if (losowa == 3 && getX() != 0) {
                    noweX--;
                    wychodzizamape = false;
                }
            }

            if (swiat.czyPolePuste(noweX, noweY)) {
                pustepole = true;
            }

            if (pustepole) {
                List<Organizm> kopiaOrganizmow = swiat.pobierzOrganizmy();
                Organizm nowyOrganizm = nowyOrganizm(noweX, noweY, swiat);
                kopiaOrganizmow.add(nowyOrganizm);
                swiat.ustawOrganizmy(kopiaOrganizmow);
            }
        }
    }

    @Override
    public boolean czyOdbilAtak(Organizm atakujacy) {
        return false;
    }

    @Override
    public abstract void rysowanie(Graphics g, int cellSize);

    @Override
    public abstract Organizm nowyOrganizm(int x, int y, Swiat swiat);
}
