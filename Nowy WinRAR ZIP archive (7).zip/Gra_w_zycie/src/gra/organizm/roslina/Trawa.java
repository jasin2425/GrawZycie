package gra.organizm.roslina;

import gra.Swiat;
import gra.organizm.Organizm;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;

public class Trawa extends Roslina {
    public Trawa(int x, int y, Swiat swiat) {
        super(x, y, swiat);
        this.sila = 0;
        this.inicjatywa = 0;
    }

    @Override
    public void rysowanie(Graphics g, int cellSize) {
        int fontSize = cellSize - 6;
        g.setFont(new Font("Segoe UI Emoji", Font.PLAIN, fontSize));
        g.setColor(new Color(0, 100, 0));  
        g.drawString("\uD83C\uDF3F", getX() * cellSize - 1, getY() * cellSize + cellSize - 5);  
    }

    @Override
    public char getGatunek() {
        return 'T';
    }

    @Override
    public Organizm nowyOrganizm(int x, int y, Swiat swiat) {
        return new Trawa(x, y, swiat);
    }
}
