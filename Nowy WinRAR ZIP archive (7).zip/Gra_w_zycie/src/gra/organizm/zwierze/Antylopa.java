package gra.organizm.zwierze;

import gra.Swiat;
import gra.organizm.Organizm;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;
import java.util.Random;
import javax.swing.JOptionPane;

public class Antylopa extends Zwierze {
    public Antylopa(int x, int y, Swiat swiat) {
        super(x, y, swiat);
        this.sila = 4;
        this.inicjatywa = 4;
    }

    @Override
    public void akcja() {
        boolean wychodzizamape = true;
        int noweX = getX();
        int noweY = getY();
        Random rand = new Random();

        while (wychodzizamape) {
            noweX = getX();
            noweY = getY();
            int losowa = rand.nextInt(4);

            if (losowa == 0 && getY() > 1) {
                noweY -= 2;
                wychodzizamape = false;
            } else if (losowa == 1 && getY() < getSwiat().getWysokosc() - 2) {
                noweY += 2;
                wychodzizamape = false;
            } else if (losowa == 2 && getX() < getSwiat().getSzerokosc() - 2) {
                noweX += 2;
                wychodzizamape = false;
            } else if (losowa == 3 && getX() > 1) {
                noweX -= 2;
                wychodzizamape = false;
            }
        }

        if (getSwiat().czyPolePuste(noweX, noweY)) {
            setX(noweX);
            setY(noweY);
        } else {
            Organizm organizm = getSwiat().getOrganizm(noweX, noweY);
            if (!organizm.czyOdbilAtak(this)) {
                setX(noweX);
                setY(noweY);
                organizm.kolizja(this);
            }
        }
    }

    @Override
    public void kolizja(Organizm organizm) {
        Random rand = new Random();
        if (organizm.getGatunek() != getGatunek()) {
            if (organizm.getSila() >= getSila()) {
                if (rand.nextInt(2) == 1) {
                    getSwiat().usunOrganizm(this);
                } else {
                    losowePole(this);
                }
            } else {
                getSwiat().usunOrganizm(organizm);
            }
        } else {
            int newX = getX();
            int newY = getY() - 1;
            if (newY < 0) {
                newY = getY() + 1;
            }
            Organizm nowyOrganizm = nowyOrganizm(newX, newY, getSwiat());
            getSwiat().dodajOrganizm(nowyOrganizm);
        }
    }

    public void losowePole(Organizm organizm) {
        int[] dirs = {-1, 1};
        int newX = organizm.getX();
        int newY = organizm.getY();
        for (int dir : dirs) {
            if (getSwiat().czyPolePuste(newX + dir, newY)) {
                organizm.setX(newX + dir);
                return;
            }
            if (getSwiat().czyPolePuste(newX, newY + dir)) {
                organizm.setY(newY + dir);
                return;
            }
        }
    }

    @Override
    public void rysowanie(Graphics g, int cellSize) {
        int fontSize = cellSize - 6;
        g.setFont(new Font("Segoe UI Emoji", Font.PLAIN, fontSize));
        g.setColor(new Color(130, 128, 29));  
        g.drawString("\uD83E\uDD93", getX() * cellSize - 1, getY() * cellSize + cellSize - 5);
    }

    @Override
    public char getGatunek() {
        return 'A';
    }

    @Override
    public Organizm nowyOrganizm(int x, int y, Swiat swiat) {
        return new Antylopa(x, y, swiat);
    }
}
