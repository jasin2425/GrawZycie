package gra.organizm.zwierze;

import gra.Swiat;
import gra.organizm.Organizm;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.JOptionPane;

public class Czlowiek extends Zwierze implements KeyListener {
    private boolean czyUmiejetnosc;
    private int pozostaleTuryUmiejetnosci;
    private boolean ruchWykonany;
    private char kierunek;

    public Czlowiek(int x, int y, Swiat swiat) {
        super(x, y, swiat);
        this.sila = 5;
        this.inicjatywa = 4;
        this.czyUmiejetnosc = false;
        this.pozostaleTuryUmiejetnosci = 0;
        this.ruchWykonany = false;
        this.kierunek = ' ';
    }

    @Override
    public void akcja() {
        if (!czyUmiejetnosc && pozostaleTuryUmiejetnosci == 0) {
            int response = JOptionPane.showConfirmDialog(null, "Aktywuj Tarcze Alazura?", "Umiejętność",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                czyUmiejetnosc = true;
                pozostaleTuryUmiejetnosci = 10;
            }
        }

        ruchWykonany = false;

         
        while (!ruchWykonany) {
            try {
                Thread.sleep(100); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        int noweX = getX();
        int noweY = getY();

        switch (kierunek) {
            case 'L':
                if (getX() > 0) noweX--;
                break;
            case 'R':
                if (getX() < swiat.getSzerokosc() - 1) noweX++;
                break;
            case 'D':
                if (getY() < swiat.getWysokosc() - 1) noweY++;
                break;
            case 'U':
                if (getY() > 0) noweY--;
                break;
        }

        if (swiat.czyPolePuste(noweX, noweY)) {
            setX(noweX);
            setY(noweY);
        } else {
            Organizm organizm = swiat.getOrganizm(noweX, noweY);
            if (!organizm.czyOdbilAtak(this)) {
                setX(noweX);
                setY(noweY);
                organizm.kolizja(this);
            }
        }

        if (pozostaleTuryUmiejetnosci > 0) {
            pozostaleTuryUmiejetnosci--;
            if(pozostaleTuryUmiejetnosci>5)
            {
            	int k=pozostaleTuryUmiejetnosci-5;
            System.out.println("pozostale tury umiejetnosci: "+ k);
            }
        }
        if (pozostaleTuryUmiejetnosci < 6) {
            czyUmiejetnosc = false;
            System.out.println("czy umiejetnosc wlaczona: " + czyUmiejetnosc);
        }
    }

    @Override
    public boolean czyOdbilAtak(Organizm atakujacy) {
        if (czyUmiejetnosc) {
            System.out.println("Atak Odbity");
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            losoweMiejsce(atakujacy);
            return true;
        }
        return false;
    }

    private void losoweMiejsce(Organizm organizm) {
        Random rand = new Random();
        int noweX = getX();
        int noweY = getY();
        boolean znalezionoPustePole = false;

        while (!znalezionoPustePole) {
            int kierunek = rand.nextInt(4);
            noweX = getX();
            noweY = getY();

            switch (kierunek) {
                case 0:  
                    if (getX() > 0) noweX--;
                    break;
                case 1:  
                    if (getX() < swiat.getSzerokosc() - 1) noweX++;
                    break;
                case 2:  
                    if (getY() < swiat.getWysokosc() - 1) noweY++;
                    break;
                case 3:  
                    if (getY() > 0) noweY--;
                    break;
            }

            if (swiat.czyPolePuste(noweX, noweY)) {
                znalezionoPustePole = true;
            }
        }

        organizm.setX(noweX);
        organizm.setY(noweY);
    }

    @Override
    public void rysowanie(Graphics g, int cellSize) {
        int fontSize = cellSize - 6;
        g.setFont(new Font("Segoe UI Emoji", Font.PLAIN, fontSize));
        g.setColor(new Color(0, 0, 0));
        g.drawString("\uD83E\uDD77", getX() * cellSize-1, getY() * cellSize + cellSize-5);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();

        switch (keyCode) {
            case KeyEvent.VK_LEFT:
                kierunek = 'L';
                break;
            case KeyEvent.VK_RIGHT:
                kierunek = 'R';
                break;
            case KeyEvent.VK_UP:
                kierunek = 'U';
                break;
            case KeyEvent.VK_DOWN:
                kierunek = 'D';
                break;
            default:
                return;
        }

        ruchWykonany = true;
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public char getGatunek() {
        return 'C';
    }

    @Override
    public Organizm nowyOrganizm(int x, int y, Swiat swiat) {
        return new Czlowiek(x, y, swiat);
    }

    public boolean isCzyUmiejetnosc() {
        return czyUmiejetnosc;
    }

    public void setCzyUmiejetnosc(boolean czyUmiejetnosc) {
        this.czyUmiejetnosc = czyUmiejetnosc;
    }

    public int getPozostaleTuryUmiejetnosci() {
        return pozostaleTuryUmiejetnosci;
    }

    public void setPozostaleTuryUmiejetnosci(int pozostaleTuryUmiejetnosci) {
        this.pozostaleTuryUmiejetnosci = pozostaleTuryUmiejetnosci;
    }
}
