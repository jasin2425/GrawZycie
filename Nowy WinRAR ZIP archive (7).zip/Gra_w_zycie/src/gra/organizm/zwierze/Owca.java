package gra.organizm.zwierze;

import gra.Swiat;
import gra.organizm.Organizm;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
public class Owca extends Zwierze {
    public Owca(int x, int y, Swiat swiat) {
        super(x, y, swiat);
        this.sila = 4;
        this.inicjatywa = 4;
    }

    @Override
    public void rysowanie(Graphics g, int cellSize) {
    	int fontSize = cellSize - 6;
        g.setFont(new Font("Segoe UI Emoji", Font.PLAIN, fontSize));
        g.setColor(new Color(79, 110, 120));
        g.drawString("\uD83D\uDC11", getX() * cellSize-1, getY() * cellSize + cellSize-5);
    }
    @Override
    public char getGatunek() {
        return 'O';
    }

    @Override
    public Organizm nowyOrganizm(int x, int y, Swiat swiat) {
        return new Owca(x, y, swiat);
    }
}
