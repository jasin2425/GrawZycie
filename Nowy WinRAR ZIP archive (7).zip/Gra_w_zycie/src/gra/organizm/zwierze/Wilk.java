package gra.organizm.zwierze;

import gra.Swiat;
import gra.organizm.Organizm;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Wilk extends Zwierze {
    public Wilk(int x, int y, Swiat swiat) {
        super(x, y, swiat);
        this.sila = 9;
        this.inicjatywa = 5;
    }

    @Override
    public void rysowanie(Graphics g, int cellSize) {
    	int fontSize = cellSize - 6;
        g.setFont(new Font("Segoe UI Emoji", Font.PLAIN, fontSize));
        g.setColor(new Color(139, 0, 0));
        g.drawString("\uD83D\uDC3A", getX() * cellSize-1, getY() * cellSize + cellSize-5);
    }

    @Override
    public char getGatunek() {
        return 'W';
    }

    @Override
    public Organizm nowyOrganizm(int x, int y, Swiat swiat) {
        return new Wilk(x, y, swiat);
    }
}
