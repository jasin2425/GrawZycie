package gra.organizm.zwierze;

import gra.Swiat;
import gra.organizm.Organizm;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;
import java.util.Random;

public class Zolw extends Zwierze {
    public Zolw(int x, int y, Swiat swiat) {
        super(x, y, swiat);
        this.sila = 2;
        this.inicjatywa = 1;
    }

    @Override
    public void akcja() {
        Random rand = new Random();
        if (rand.nextInt(4) == 0) {  
            boolean wychodzizamape = true;
            int noweX = getX();
            int noweY = getY();

            while (wychodzizamape) {
                noweX = getX();
                noweY = getY();
                int losowa = rand.nextInt(4);

                if (losowa == 0 && getY() != 0) {
                    noweY--;
                    wychodzizamape = false;
                } else if (losowa == 1 && getY() != getSwiat().getWysokosc() - 1) {
                    noweY++;
                    wychodzizamape = false;
                } else if (losowa == 2 && getX() != getSwiat().getSzerokosc() - 1) {
                    noweX++;
                    wychodzizamape = false;
                } else if (losowa == 3 && getX() != 0) {
                    noweX--;
                    wychodzizamape = false;
                }
            }

            if (swiat.czyPolePuste(noweX, noweY)) {
                setX(noweX);
                setY(noweY);
            } else {
                Organizm organizm = getSwiat().getOrganizm(noweX, noweY);
                if (organizm != null && !organizm.czyOdbilAtak(this)) {
                    setX(noweX);
                    setY(noweY);
                    organizm.kolizja(this);
                }
            }
        }
    }

    @Override
    public boolean czyOdbilAtak(Organizm atakujacy) {
        if (atakujacy.getSila() < 5) {
            System.out.println("Atak Odbity");
            return true;
        }
        return false;
    }

    @Override
    public void rysowanie(Graphics g, int cellSize) {
        int fontSize = cellSize - 6;
        g.setFont(new Font("Segoe UI Emoji", Font.PLAIN, fontSize));
        g.setColor(Color.GREEN.darker());  
        g.drawString("\uD83D\uDC22", getX() * cellSize - 1, getY() * cellSize + cellSize - 5);  
    }

    @Override
    public char getGatunek() {
        return 'Z';
    }

    @Override
    public Organizm nowyOrganizm(int x, int y, Swiat swiat) {
        return new Zolw(x, y, swiat);
    }
}
