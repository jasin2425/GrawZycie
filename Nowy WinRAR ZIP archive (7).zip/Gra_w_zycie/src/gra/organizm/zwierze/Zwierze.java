package gra.organizm.zwierze;


import java.util.Random;
import gra.Swiat;
import gra.organizm.Organizm;
import java.awt.Font;
import java.awt.Graphics;

public abstract class Zwierze extends Organizm {
    public Zwierze(int x, int y, Swiat swiat) {
        super(x, y, swiat);
    }

    public Zwierze(int x, int y) {
        super(x, y);
    }

    @Override
    public void akcja() {
        boolean wychodzizamape = true;
        int noweX = pozycja.x;
        int noweY = pozycja.y;
        Random rand = new Random();

        while (wychodzizamape) {
            noweX = pozycja.x;
            noweY = pozycja.y;
            int losowa = rand.nextInt(4);

            if (losowa == 0 && getY() != 0) {
                wychodzizamape = false;
                noweY--;
            } else if (losowa == 1 && getY() != getSwiat().getWysokosc() - 1) {
                wychodzizamape = false;
                noweY++;
            } else if (losowa == 2 && getX() != getSwiat().getSzerokosc() - 1) {
                wychodzizamape = false;
                noweX++;
            } else if (losowa == 3 && getX() != 0) {
                wychodzizamape = false;
                noweX--;
            }
        }

        if (swiat.czyPolePuste(noweX, noweY) && !wychodzizamape) {
            pozycja.x = noweX;
            pozycja.y = noweY;
        } else {
            Organizm organizm = getSwiat().getOrganizm(noweX, noweY);
            if (!organizm.czyOdbilAtak(this)) {
                pozycja.x = noweX;
                pozycja.y = noweY;
                organizm.kolizja(this);
            }
        }
    }

    @Override
    public boolean czyOdbilAtak(Organizm atakujacy) {
        return false;
    }

    @Override
    public abstract void rysowanie(Graphics g, int cellSize);

    @Override
    public abstract Organizm nowyOrganizm(int x, int y, Swiat swiat);

    @Override
    public abstract char getGatunek();
}
