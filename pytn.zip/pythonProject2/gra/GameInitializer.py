import tkinter as tk
from tkinter import messagebox
from gra.Swiat import Swiat
from gra.Main import MainApp, bazowe_organizmy
from gra.organizm.Zwierzeta.Wilk import Wilk
from gra.organizm.Zwierzeta.Owca import Owca
from gra.organizm.Zwierzeta.Czlowiek import Czlowiek
from gra.organizm.Zwierzeta.Lis import Lis
from gra.organizm.Zwierzeta.Antylopa import Antylopa
from gra.organizm.Zwierzeta.Zolw import Zolw
from gra.organizm.Rosliny.Trawa import Trawa
from gra.organizm.Rosliny.Guarana import Guarana
from gra.organizm.Rosliny.Mlecz import Mlecz
from gra.organizm.Rosliny.Barszcz import Barszcz
from gra.organizm.Zwierzeta.Cyberowca import Cyberowca
import random

class GameInitializer:
    def __init__(self):
        self.start_frame = tk.Tk()
        self.start_frame.title("Gra o Życie - Ekran Startowy")
        self.start_frame.geometry("400x200")  # Zwiększenie rozmiaru okna
        self.start_frame.resizable(False, False)
        self.start_frame.grid_rowconfigure(0, weight=1)
        self.start_frame.grid_rowconfigure(1, weight=1)

        nowa_gra_button = tk.Button(self.start_frame, text="Nowa Gra", command=self.uruchom_nowa_gre, font=("Arial", 14))
        nowa_gra_button.grid(row=0, column=0, sticky="nsew")

        wczytaj_gra_button = tk.Button(self.start_frame, text="Wczytaj Grę", command=self.wczytaj_gre, font=("Arial", 14))
        wczytaj_gra_button.grid(row=1, column=0, sticky="nsew")

        self.start_frame.mainloop()

    def uruchom_nowa_gre(self):
        panel = tk.Toplevel(self.start_frame)
        panel.title("Podaj wymiary mapy")
        szerokosc_label = tk.Label(panel, text="Szerokość:", font=("Arial", 12))
        szerokosc_label.grid(row=0, column=0)
        szerokosc_field = tk.Entry(panel, font=("Arial", 12))
        szerokosc_field.grid(row=0, column=1)
        wysokosc_label = tk.Label(panel, text="Wysokość:", font=("Arial", 12))
        wysokosc_label.grid(row=1, column=0)
        wysokosc_field = tk.Entry(panel, font=("Arial", 12))
        wysokosc_field.grid(row=1, column=1)

        def on_ok():
            try:
                szerokosc = int(szerokosc_field.get())
                wysokosc = int(wysokosc_field.get())
                panel.destroy()
                self.start_frame.destroy()
                swiat = Swiat(szerokosc, wysokosc)
                self.dodaj_organizmy(swiat, szerokosc, wysokosc)
                self.uruchom_gre(swiat)
            except ValueError:
                messagebox.showerror("Błąd", "Nieprawidłowe wymiary")

        ok_button = tk.Button(panel, text="OK", command=on_ok, font=("Arial", 12))
        ok_button.grid(row=2, columnspan=2)

    def wczytaj_gre(self):
        self.start_frame.destroy()
        swiat = Swiat(20, 20)
        organizmy = bazowe_organizmy(swiat)
        swiat.wczytaj(organizmy)
        self.uruchom_gre(swiat)

    def uruchom_gre(self, swiat):
        main_frame = MainApp(swiat)
        for organizm in swiat.pobierz_organizmy():
            if isinstance(organizm, Czlowiek):
                main_frame.bind("<Key>", organizm.on_key_press)
                break
        main_frame.focus_set()
        main_frame.mainloop()

    def dodaj_organizmy(self, swiat, szerokosc, wysokosc):
        organizmy = [
            Wilk(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
            Owca(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
          #  Owca(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
            Czlowiek(0, 0, swiat),
          #  Antylopa(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
          #  Lis(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
          #  Zolw(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
          #  Trawa(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
          #  Guarana(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
          #  Mlecz(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat),
          #  Barszcz(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat)
          Cyberowca(random.randint(0, szerokosc - 1), random.randint(0, wysokosc - 1), swiat)  # Dodanie Cyberowcy

        ]

        for organizm in organizmy:
            swiat.dodaj_organizm(organizm)

if __name__ == "__main__":
    GameInitializer()
