import tkinter as tk
from tkinter import messagebox
from gra.Swiat import Swiat
from gra.Plansza import Plansza
from gra.organizm.Zwierzeta.Wilk import Wilk
from gra.organizm.Zwierzeta.Owca import Owca
from gra.organizm.Zwierzeta.Czlowiek import Czlowiek
from gra.organizm.Zwierzeta.Lis import Lis
from gra.organizm.Zwierzeta.Antylopa import Antylopa
from gra.organizm.Zwierzeta.Zolw import Zolw
from gra.organizm.Rosliny.Trawa import Trawa
from gra.organizm.Rosliny.Guarana import Guarana
from gra.organizm.Rosliny.Mlecz import Mlecz
from gra.organizm.Rosliny.Barszcz import Barszcz
from gra.organizm.Zwierzeta.Cyberowca import Cyberowca

def bazowe_organizmy(swiat):
    return [
        Wilk(0, 0, swiat),
        Owca(0, 0, swiat),
        Czlowiek(0, 0, swiat),
        Lis(0, 0, swiat),
        Antylopa(0, 0, swiat),
        Zolw(0, 0, swiat),
        Trawa(0, 0, swiat),
        Guarana(0, 0, swiat),
        Mlecz(0, 0, swiat),
        Barszcz(0, 0, swiat),
        Cyberowca(0, 0, swiat)
    ]


class MainApp(tk.Tk):
    def __init__(self, swiat):
        super().__init__()
        self.title("Gra o Życie")

        # Ustawienia okna
        self.width = 600
        self.height = 600
        self.geometry(f"{self.width}x{self.height}")
        self.resizable(False, False)

        self._swiat = swiat
        self._swiat.set_main_app(self)  # Ustawienie odniesienia do main_app

        self._plansza = Plansza(self, self._swiat.pobierz_organizmy(), self._swiat.get_szerokosc(),
                               self._swiat.get_wysokosc(), self._swiat)
        self._plansza.pack(side=tk.TOP)

        self._next_turn_button = tk.Button(self, text="Nowa Tura", command=self.next_turn)
        self._next_turn_button.pack(side=tk.BOTTOM)

    def next_turn(self):
        self._next_turn_button.config(state=tk.DISABLED)
        self.after(500, self.perform_turn)

    def perform_turn(self):
        self._swiat.wykonaj_ture(self._plansza)
        self._swiat.zapis()
        self._plansza.repaint()
        self._next_turn_button.config(state=tk.NORMAL)


if __name__ == "__main__":
    from gra.GameInitializer import GameInitializer

    GameInitializer()