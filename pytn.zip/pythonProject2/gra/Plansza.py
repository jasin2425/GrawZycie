import tkinter as tk
from tkinter import simpledialog
from gra.organizm.Zwierzeta.Wilk import Wilk
from gra.organizm.Zwierzeta.Owca import Owca
from gra.organizm.Zwierzeta.Czlowiek import Czlowiek
from gra.organizm.Zwierzeta.Lis import Lis
from gra.organizm.Zwierzeta.Antylopa import Antylopa
from gra.organizm.Zwierzeta.Zolw import Zolw
from gra.organizm.Rosliny.Trawa import Trawa
from gra.organizm.Rosliny.Guarana import Guarana
from gra.organizm.Rosliny.Mlecz import Mlecz
from gra.organizm.Rosliny.Barszcz import Barszcz

class Plansza(tk.Canvas):
    def __init__(self, master, organizmy, szerokosc, wysokosc, swiat, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self._organizmy = organizmy
        self._szerokosc = szerokosc
        self._wysokosc = wysokosc
        self._swiat = swiat
        self._width = 500
        self._height = 500
        self._cellwidth = self._width // self._szerokosc
        self._cellheight = self._height // self._wysokosc
        self.configure(width=self._width, height=self._height)
        self.draw_grid()
        self.bind("<Button-1>", self.on_click)

    def draw_grid(self):
        for i in range(self._szerokosc):
            for j in range(self._wysokosc):
                x1 = i * self._cellwidth
                y1 = j * self._cellheight
                x2 = x1 + self._cellwidth
                y2 = y1 + self._cellheight
                self.create_rectangle(x1, y1, x2, y2, fill="white", outline="black")
                organizm = self._swiat.get_organizm(i, j)
                if organizm:
                    organizm.rysowanie(self, self._cellwidth, self._cellheight)

    def repaint(self):
        self.delete("all")
        self.draw_grid()

    def on_click(self, event):
        x = event.x // self._cellwidth
        y = event.y // self._cellheight
        if self._swiat.czy_pole_puste(x, y):
            options = ["Wilk", "Owca", "Antylopa", "Lis", "Zolw", "Guarana", "Mlecz", "Barszcz"]
            wybor = simpledialog.askstring("Dodaj Organizm", "Wybierz organizm: " + ', '.join(options))
            if wybor:
                organizm = None
                if wybor == "Wilk":
                    organizm = Wilk(x, y, self._swiat)
                elif wybor == "Owca":
                    organizm = Owca(x, y, self._swiat)
                elif wybor == "Antylopa":
                    organizm = Antylopa(x, y, self._swiat)
                elif wybor == "Lis":
                    organizm = Lis(x, y, self._swiat)
                elif wybor == "Zolw":
                    organizm = Zolw(x, y, self._swiat)
                elif wybor == "Guarana":
                    organizm = Guarana(x, y, self._swiat)
                elif wybor == "Mlecz":
                    organizm = Mlecz(x, y, self._swiat)
                elif wybor == "Barszcz":
                    organizm = Barszcz(x, y, self._swiat)

                if organizm:
                    self._swiat.dodaj_organizm(organizm)
                    self.repaint()
