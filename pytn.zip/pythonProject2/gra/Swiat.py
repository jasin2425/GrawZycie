import time
from gra.organizm.Zwierzeta.Czlowiek import Czlowiek  # Dodaj ten import

class Swiat:
    def __init__(self, szerokosc, wysokosc):
        self._szerokosc = szerokosc
        self._wysokosc = wysokosc
        self._organizmy = []
        self._main_app = None

    def set_main_app(self, main_app):
        self._main_app = main_app

    def get_szerokosc(self):
        return self._szerokosc

    def get_wysokosc(self):
        return self._wysokosc

    def czy_pole_puste(self, x, y):
        for organizm in self._organizmy:
            if organizm.get_x() == x and organizm.get_y() == y:
                return False
        return True

    def wykonaj_ture(self, plansza):
        kopia_organizmow = sorted(self._organizmy, key=lambda o: o.get_inicjatywa(), reverse=True)
        for organizm in kopia_organizmow:
            if organizm.get_sila() > -10:
                print(f"Ruch gracza: {organizm.get_gatunek()}")
                organizm.akcja()
                plansza.repaint()
                plansza.update()
                time.sleep(0.5)
        self.zapis()

    def zapis(self):
        with open("stangry.txt", "w") as f:
            f.write(f"{self._szerokosc} {self._wysokosc} {len(self._organizmy)}\n")
            for organizm in self._organizmy:
                if organizm and organizm.get_sila() > -2:
                    f.write(f"{organizm.get_gatunek()} {organizm.get_x()} {organizm.get_y()} {organizm.get_sila()}")
                    if isinstance(organizm, Czlowiek):
                        f.write(f" {organizm.czy_umiejetnosc} {organizm.pozostale_tury_umiejetnosci}")
                    f.write("\n")

    def wczytaj(self, bazowe):
        with open("stangry.txt", "r") as f:
            lines = f.readlines()
            self._szerokosc, self._wysokosc, ile_org = map(int, lines[0].split())
            for line in lines[1:]:
                data = line.split()
                gatunek = data[0]
                x, y, sila = map(int, data[1:4])
                czy_umiejetnosc = False
                pozostale_tury_umiejetnosci = 0

                if gatunek == 'C':
                    czy_umiejetnosc = data[4] == 'True'
                    pozostale_tury_umiejetnosci = int(data[5])

                for organizm in bazowe:
                    if organizm.get_gatunek() == gatunek:
                        nowy = organizm.nowy_organizm(x, y, self)
                        nowy.ustaw_sile(sila)
                        if isinstance(nowy, Czlowiek):
                            nowy.czy_umiejetnosc = czy_umiejetnosc
                            nowy.pozostale_tury_umiejetnosci = pozostale_tury_umiejetnosci
                        self.dodaj_organizm(nowy)

    def get_organizm(self, x, y):
        for organizm in self._organizmy:
            if organizm.get_x() == x and organizm.get_y() == y:
                return organizm
        return None

    def usun_organizm(self, organizm):
        self._organizmy.remove(organizm)

    def ustaw_organizmy(self, nowe_organizmy):
        self._organizmy = nowe_organizmy

    def pobierz_organizmy(self):
        return self._organizmy

    def dodaj_organizm(self, nowy_organizm):
        self._organizmy.append(nowy_organizm)
