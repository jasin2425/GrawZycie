from abc import ABC, abstractmethod
import time

class Pozycja:
    def __init__(self, x, y):
        self._x = x
        self._y = y

class Organizm(ABC):
    def __init__(self, x, y, swiat=None):
        self._sila = 0
        self._inicjatywa = 0
        self._pozycja = Pozycja(x, y)
        self._swiat = swiat

    def get_sila(self):
        return self._sila

    def get_inicjatywa(self):
        return self._inicjatywa

    def get_x(self):
        return self._pozycja._x

    def get_y(self):
        return self._pozycja._y

    def kolizja(self, organizm):
        kopia_organizmy = self._swiat.pobierz_organizmy()

        if organizm.get_gatunek() != self.get_gatunek():
            if organizm.get_sila() >= self.get_sila():
                print(f"Kolizja! {organizm.get_gatunek()} pokonuje {self.get_gatunek()}")
                time.sleep(0.3)
                self._swiat.usun_organizm(self)
            else:
                print(f"Kolizja! {self.get_gatunek()} pokonuje {organizm.get_gatunek()}")
                time.sleep(0.3)
                self._swiat.usun_organizm(organizm)
        else:
            new_x = self._pozycja._x
            new_y = self._pozycja._y - 1
            if new_y < 0:
                new_y = self._pozycja._y + 1
            print(f"Kolizja! {self.get_gatunek()} tworzy nowy {organizm.get_gatunek()}")

            time.sleep(0.3)

            nowy = self.nowy_organizm(new_x, new_y, self._swiat)
            kopia_organizmy.append(nowy)
            self._swiat.ustaw_organizmy(kopia_organizmy)

    def ustaw_sile(self, nowa_sila):
        self._sila = nowa_sila

    def set_x(self, new_x):
        self._pozycja._x = new_x

    def set_y(self, new_y):
        self._pozycja._y = new_y

    def get_swiat(self):
        return self._swiat

    @abstractmethod
    def akcja(self):
        pass

    @abstractmethod
    def rysowanie(self, g, cell_size):
        pass

    @abstractmethod
    def czy_odbil_atak(self, atakujacy):
        pass

    @abstractmethod
    def nowy_organizm(self, x, y, swiat):
        pass

    @abstractmethod
    def get_gatunek(self):
        pass