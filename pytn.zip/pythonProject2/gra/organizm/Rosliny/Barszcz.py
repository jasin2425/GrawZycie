import random
from gra.organizm.Rosliny.Roslina import Roslina
from gra.organizm.Zwierzeta.Zwierze import Zwierze

class Barszcz(Roslina):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 10
        self._inicjatywa = 0

    def akcja(self):
        nowe_x, nowe_y = self.get_x(), self.get_y()
        self.niszczenie(nowe_x, nowe_y)
        if random.randint(0, 3) == 0:
            if random.randint(0, 3) == 0 and self.get_y() > 0:
                nowe_y -= 1
            elif random.randint(0, 3) == 1 and self.get_y() < self._swiat.get_wysokosc() - 1:
                nowe_y += 1
            elif random.randint(0, 3) == 2 and self.get_x() < self._swiat.get_szerokosc() - 1:
                nowe_x += 1
            elif random.randint(0, 3) == 3 and self.get_x() > 0:
                nowe_x -= 1

            if self._swiat.czy_pole_puste(nowe_x, nowe_y):
                nowy_organizm = self.nowy_organizm(nowe_x, nowe_y, self._swiat)
                self._swiat.dodaj_organizm(nowy_organizm)

    def niszczenie(self, x, y):
        from gra.organizm.Zwierzeta.Cyberowca import Cyberowca

        directions = [(0, 1), (0, -1), (-1, 0), (1, 0)]
        for dir in directions:
            new_x, new_y = x + dir[0], y + dir[1]
            if not self._swiat.czy_pole_puste(new_x, new_y):
                organizm = self._swiat.get_organizm(new_x, new_y)
                if organizm and isinstance(organizm, Zwierze) and not isinstance(organizm, Cyberowca):
                    self._swiat.usun_organizm(organizm)
                    print(f"Kolizja! {self.get_gatunek()} pokonuje {organizm.get_gatunek()}")

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F335",  # Emoji barszczu
                           font=("Segoe UI Emoji", font_size),
                           fill="green")  # Green

    def get_gatunek(self):
        return 'B'

    def nowy_organizm(self, x, y, swiat):
        return Barszcz(x, y, swiat)
