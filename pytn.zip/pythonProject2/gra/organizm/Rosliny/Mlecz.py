import random
from gra.organizm.Rosliny.Roslina import Roslina


class Mlecz(Roslina):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 0
        self._inicjatywa = 0

    def akcja(self):
        for _ in range(3):  # Attempt to spread three times
            if random.randint(0, 3) == 0:  # 25% chance to spread
                nowe_x, nowe_y = self.get_x(), self.get_y()
                if random.randint(0, 3) == 0 and self.get_y() > 0:
                    nowe_y -= 1
                elif random.randint(0, 3) == 1 and self.get_y() < self._swiat.get_wysokosc() - 1:
                    nowe_y += 1
                elif random.randint(0, 3) == 2 and self.get_x() < self._swiat.get_szerokosc() - 1:
                    nowe_x += 1
                elif random.randint(0, 3) == 3 and self.get_x() > 0:
                    nowe_x -= 1

                if self._swiat.czy_pole_puste(nowe_x, nowe_y):
                    nowy_organizm = self.nowy_organizm(nowe_x, nowe_y, self._swiat)
                    self._swiat.dodaj_organizm(nowy_organizm)

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F33C",  # Emoji mlecza
                           font=("Segoe UI Emoji", font_size),
                           fill="#7A225E")  # Dark Magenta

    def get_gatunek(self):
        return 'M'

    def nowy_organizm(self, x, y, swiat):
        return Mlecz(x, y, swiat)
