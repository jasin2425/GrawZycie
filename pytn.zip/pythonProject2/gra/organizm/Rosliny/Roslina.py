import random
from gra.organizm.Organizm import Organizm

class Roslina(Organizm):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)

    def akcja(self):
        rand = random.Random()
        if rand.randint(0, 3) == 0:  # 25% szansa na rozprzestrzenienie
            wychodzizamape = True
            pustepole = False
            nowe_x = self.get_x()
            nowe_y = self.get_y()

            while wychodzizamape:
                nowe_x = self.get_x()
                nowe_y = self.get_y()
                losowa = rand.randint(0, 3)

                if losowa == 0 and self.get_y() != 0:
                    nowe_y -= 1
                    wychodzizamape = False
                elif losowa == 1 and self.get_y() != self._swiat.get_wysokosc() - 1:
                    nowe_y += 1
                    wychodzizamape = False
                elif losowa == 2 and self.get_x() != self._swiat.get_szerokosc() - 1:
                    nowe_x += 1
                    wychodzizamape = False
                elif losowa == 3 and self.get_x() != 0:
                    nowe_x -= 1
                    wychodzizamape = False

            if self._swiat.czy_pole_puste(nowe_x, nowe_y):
                pustepole = True

            if pustepole:
                kopia_organizmy = self._swiat.pobierz_organizmy()
                nowy_organizm = self.nowy_organizm(nowe_x, nowe_y, self.swiat)
                kopia_organizmy.append(nowy_organizm)
                self._swiat.ustaw_organizmy(kopia_organizmy)

    def czy_odbil_atak(self, atakujacy):
        return False

    def rysowanie(self, g, cell_size):
        raise NotImplementedError("This method should be overridden by subclasses")

    def nowy_organizm(self, x, y, swiat):
        raise NotImplementedError("This method should be overridden by subclasses")
