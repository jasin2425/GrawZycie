from gra.organizm.Rosliny.Roslina import Roslina

class Trawa(Roslina):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 0
        self._inicjatywa = 0

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F33F",  # Emoji trawy
                           font=("Segoe UI Emoji", font_size),
                           fill="#006400")  # Dark Green

    def get_gatunek(self):
        return 'T'

    def nowy_organizm(self, x, y, swiat):
        return Trawa(x, y, swiat)
