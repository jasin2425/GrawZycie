import random
import time
from gra.organizm.Organizm import Organizm
from gra.organizm.Zwierzeta.Zwierze import Zwierze

class Antylopa(Zwierze):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 4
        self._inicjatywa = 4

    def akcja(self):
        wychodzizamape = True
        noweX = self.get_x()
        noweY = self.get_y()
        rand = random.Random()

        while wychodzizamape:
            noweX = self.get_x()
            noweY = self.get_y()
            losowa = rand.randint(0, 3)

            if losowa == 0 and self.get_y() > 1:
                noweY -= 2
                wychodzizamape = False
            elif losowa == 1 and self.get_y() < self._swiat.get_wysokosc() - 2:
                noweY += 2
                wychodzizamape = False
            elif losowa == 2 and self.get_x() < self._swiat.get_szerokosc() - 2:
                noweX += 2
                wychodzizamape = False
            elif losowa == 3 and self.get_x() > 1:
                noweX -= 2
                wychodzizamape = False

        if self._swiat.czy_pole_puste(noweX, noweY):
            self.set_x(noweX)
            self.set_y(noweY)
        else:
            organizm = self._swiat.get_organizm(noweX, noweY)
            if not organizm.czy_odbil_atak(self):
                self.set_x(noweX)
                self.set_y(noweY)
                organizm.kolizja(self)

    def kolizja(self, organizm):
        rand = random.Random()
        if organizm.get_gatunek() != self.get_gatunek():
            if organizm.get_sila() >= self.get_sila():
                if rand.randint(0, 1) == 1:
                    self._swiat.usun_organizm(self)
                else:
                    self.losowe_pole(self)
            else:
                self._swiat.usun_organizm(organizm)
        else:
            newX = self.get_x()
            newY = self.get_y() - 1
            if newY < 0:
                newY = self.get_y() + 1
            nowy_organizm = self.nowy_organizm(newX, newY, self._swiat)
            self._swiat.dodaj_organizm(nowy_organizm)

    def losowe_pole(self, organizm):
        dirs = [-1, 1]
        newX = organizm.get_x()
        newY = organizm.get_y()
        for dir in dirs:
            if self._swiat.czy_pole_puste(newX + dir, newY):
                organizm.set_x(newX + dir)
                return
            if self._swiat.czy_pole_puste(newX, newY + dir):
                organizm.set_y(newY + dir)
                return

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F993",  # Emoji antylopy
                           font=("Segoe UI Emoji", font_size),
                           fill="#82801D")  # Olive Green

    def get_gatunek(self):
        return 'A'

    def nowy_organizm(self, x, y, swiat):
        return Antylopa(x, y, swiat)
