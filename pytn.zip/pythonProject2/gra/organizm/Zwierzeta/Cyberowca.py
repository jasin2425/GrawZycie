import random
from gra.organizm.Zwierzeta.Zwierze import Zwierze
from gra.organizm.Zwierzeta.Owca import Owca
from gra.organizm.Rosliny.Barszcz import Barszcz

class Cyberowca(Zwierze):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 11
        self._inicjatywa = 4

    def akcja(self):
        barszcz_positions = [(organizm.get_x(), organizm.get_y()) for organizm in self._swiat.pobierz_organizmy() if
                             isinstance(organizm, Barszcz)]

        if barszcz_positions:
            closest_barszcz = min(barszcz_positions,
                                  key=lambda pos: abs(pos[0] - self.get_x()) + abs(pos[1] - self.get_y()))
            target_x, target_y = closest_barszcz
            self.move_towards(target_x, target_y)
        else:

            self.normalna_owca_akcja()

    def move_towards(self, target_x, target_y):
        nowe_x = self.get_x()
        nowe_y = self.get_y()

        if self.get_x() < target_x:
            nowe_x += 1
        elif self.get_x() > target_x:
            nowe_x -= 1
        elif self.get_y() < target_y:
            nowe_y += 1
        elif self.get_y() > target_y:
            nowe_y -= 1

        if self._swiat.czy_pole_puste(nowe_x, nowe_y):
            self.set_x(nowe_x)
            self.set_y(nowe_y)
        else:
            organizm = self._swiat.get_organizm(nowe_x, nowe_y)
            if not organizm.czy_odbil_atak(self):
                self.set_x(nowe_x)
                self.set_y(nowe_y)
                organizm.kolizja(self)

    def normalna_owca_akcja(self):
        nowe_x = self.get_x()
        nowe_y = self.get_y()
        rand = random.Random()
        losowa = rand.randint(0, 3)

        if losowa == 0 and self.get_y() > 0:
            nowe_y -= 1
        elif losowa == 1 and self.get_y() < self._swiat.get_wysokosc() - 1:
            nowe_y += 1
        elif losowa == 2 and self.get_x() < self._swiat.get_szerokosc() - 1:
            nowe_x += 1
        elif losowa == 3 and self.get_x() > 0:
            nowe_x -= 1

        if self._swiat.czy_pole_puste(nowe_x, nowe_y):
            self.set_x(nowe_x)
            self.set_y(nowe_y)
        else:
            organizm = self._swiat.get_organizm(nowe_x, nowe_y)
            if not organizm.czy_odbil_atak(self):
                self.set_x(nowe_x)
                self.set_y(nowe_y)
                organizm.kolizja(self)

    def kolizja(self, organizm):
        if isinstance(organizm, Barszcz):
            print(f"{self.get_gatunek()} zjadł {organizm.get_gatunek()}")
            self._swiat.usun_organizm(organizm)
        else:
            super().kolizja(organizm)

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F40F",  # Emoji owcy
                           font=("Segoe UI Emoji", font_size),
                           fill="#8A2BE2")  # Kolor fioletowy

    def get_gatunek(self):
        return 'Y'

    def nowy_organizm(self, x, y, swiat):
        return Cyberowca(x, y, swiat)
