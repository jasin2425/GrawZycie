import tkinter as tk
from gra.organizm.Zwierzeta.Zwierze import Zwierze
from gra.organizm.Rosliny.Roslina import Roslina
import random

class Czlowiek(Zwierze):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 5
        self._inicjatywa = 4
        self.czy_umiejetnosc = False
        self.pozostale_tury_umiejetnosci = 0
        self._ruch_wykonany = False
        self._kierunek = ' '

    def akcja(self):
        if not self.czy_umiejetnosc and self.pozostale_tury_umiejetnosci == 0:
            response = tk.messagebox.askyesno("Umiejętność", "Aktywuj Tarcze Alazura?")
            if response:
                self.czy_umiejetnosc = True
                self.pozostale_tury_umiejetnosci = 10

        self._ruch_wykonany = False

        while not self._ruch_wykonany:
            self._swiat._main_app.update()

        noweX = self.get_x()
        noweY = self.get_y()

        if self._kierunek == 'L' and self.get_x() > 0:
            noweX -= 1
        elif self._kierunek == 'R' and self.get_x() < self._swiat.get_szerokosc() - 1:
            noweX += 1
        elif self._kierunek == 'D' and self.get_y() < self._swiat.get_wysokosc() - 1:
            noweY += 1
        elif self._kierunek == 'U' and self.get_y() > 0:
            noweY -= 1

        if self._swiat.czy_pole_puste(noweX, noweY):
            self.set_x(noweX)
            self.set_y(noweY)
        else:
            organizm = self._swiat.get_organizm(noweX, noweY)
            if not organizm.czy_odbil_atak(self):
                self.set_x(noweX)
                self.set_y(noweY)
                organizm.kolizja(self)

        if self.pozostale_tury_umiejetnosci > 0:
            self.pozostale_tury_umiejetnosci -= 1
            print(f"Pozostałe tury Tarczy Alazura: {self.pozostale_tury_umiejetnosci - 5}")
        if self.pozostale_tury_umiejetnosci < 6:
            self.czy_umiejetnosc = False
            print(f"Nie można używać Mocy")

    def kolizja(self, organizm):
        if isinstance(organizm, Roslina):
            print(f"{self.get_gatunek()} zjadł {organizm.get_gatunek()} +3pkt do siły obecna siła {self.get_sila() + 3}")
            self._sila += 3
            self._swiat.usun_organizm(organizm)
        else:
            if self.czy_umiejetnosc:
                print(f"{self.get_gatunek()} odbija atak {organizm.get_gatunek()}")
                self.odsuncie_zwierze(organizm)
            else:
                if organizm.get_sila() > self.get_sila():
                    print(f"Kolizja! {organizm.get_gatunek()} pokonał {self.get_gatunek()}")
                    self._swiat.usun_organizm(self)
                else:
                    print(f"Kolizja! {self.get_gatunek()} pokonał {organizm.get_gatunek()}")
                    self._swiat.usun_organizm(organizm)

    def odsuncie_zwierze(self, organizm):
        possible_moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        random.shuffle(possible_moves)

        for dx, dy in possible_moves:
            noweX = organizm.get_x() + dx
            noweY = organizm.get_y() + dy

            if 0 <= noweX < self._swiat.get_szerokosc() and 0 <= noweY < self._swiat.get_wysokosc():
                if self._swiat.czy_pole_puste(noweX, noweY):
                    organizm.set_x(noweX)
                    organizm.set_y(noweY)
                    print(f"{organizm.get_gatunek()} został przesunięty na ({noweX}, {noweY}) przez {self.get_gatunek()}")
                    return

    def czy_odbil_atak(self, atakujacy):
        if self.czy_umiejetnosc:
            print(f"Atak {atakujacy.get_gatunek()} został odbity przez {self.get_gatunek()}")
            self.odsuncie_zwierze(atakujacy)
            return True
        return False

    def on_key_press(self, event):
        key_code = event.keysym

        if key_code == 'Left':
            self._kierunek = 'L'
        elif key_code == 'Right':
            self._kierunek = 'R'
        elif key_code == 'Up':
            self._kierunek = 'U'
        elif key_code == 'Down':
            self._kierunek = 'D'
        self._ruch_wykonany = True

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F64B",  # Emoji człowieka
                           font=("Segoe UI Emoji", font_size),
                           fill="#000000")  # Black

    def get_gatunek(self):
        return 'C'

    def nowy_organizm(self, x, y, swiat):
        return Czlowiek(x, y, swiat)