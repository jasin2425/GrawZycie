import random
from gra.organizm.Zwierzeta.Zwierze import Zwierze

class Lis(Zwierze):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 3
        self._inicjatywa = 7

    def akcja(self):
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        rand = random.Random()
        possible_moves = []

        for dx, dy in directions:
            nowe_x = self.get_x() + dx
            nowe_y = self.get_y() + dy
            if 0 <= nowe_x < self._swiat.get_szerokosc() and 0 <= nowe_y < self._swiat.get_wysokosc():
                if self._swiat.czy_pole_puste(nowe_x, nowe_y):
                    possible_moves.append((nowe_x, nowe_y))
                else:
                    organizm = self._swiat.get_organizm(nowe_x, nowe_y)
                    if organizm and organizm.get_sila() <= self.get_sila():
                        possible_moves.append((nowe_x, nowe_y))

        if not possible_moves:
            print(f"{self.get_gatunek()} pomija turę, otoczony przez silniejsze organizmy")
            return

        nowe_x, nowe_y = possible_moves[rand.randint(0, len(possible_moves) - 1)]
        if self._swiat.czy_pole_puste(nowe_x, nowe_y):
            self.set_x(nowe_x)
            self.set_y(nowe_y)
        else:
            organizm = self._swiat.get_organizm(nowe_x, nowe_y)
            if organizm and not organizm.czy_odbil_atak(self):
                self.set_x(nowe_x)
                self.set_y(nowe_y)
                organizm.kolizja(self)

    def nowy_organizm(self, x, y, swiat):
        return Lis(x, y, swiat)

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F98A",  # Emoji lisa
                           font=("Segoe UI Emoji", font_size),
                           fill="#FA9017")  # Orange

    def get_gatunek(self):
        return 'L'
