from gra.organizm.Zwierzeta.Zwierze import Zwierze

class Owca(Zwierze):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 4
        self._inicjatywa = 4

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F411",  # Emoji owcy
                           font=("Segoe UI Emoji", font_size),
                           fill="#4F6E78")  # Dark Gray

    def get_gatunek(self):
        return 'O'

    def nowy_organizm(self, x, y, swiat):
        return Owca(x, y, swiat)
