from gra.organizm.Zwierzeta.Zwierze import Zwierze

class Wilk(Zwierze):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 9
        self._inicjatywa = 5

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F43A",  # Emoji wilka
                           font=("Segoe UI Emoji", font_size),
                           fill="#8B0000")  # Dark Red

    def get_gatunek(self):
        return 'W'

    def nowy_organizm(self, x, y, swiat):
        return Wilk(x, y, swiat)

