import random
from gra.organizm.Zwierzeta.Zwierze import Zwierze

class Zolw(Zwierze):
    def __init__(self, x, y, swiat):
        super().__init__(x, y, swiat)
        self._sila = 2
        self._inicjatywa = 1

    def akcja(self):
        rand = random.Random()
        if rand.randint(0, 3) == 0:  # 25% szansa na ruch
            wychodzizamape = True
            nowe_x = self.get_x()
            nowe_y = self.get_y()

            while wychodzizamape:
                nowe_x = self.get_x()
                nowe_y = self.get_y()
                losowa = rand.randint(0, 3)

                if losowa == 0 and self.get_y() != 0:
                    nowe_y -= 1
                    wychodzizamape = False
                elif losowa == 1 and self.get_y() != self._swiat.get_wysokosc() - 1:
                    nowe_y += 1
                    wychodzizamape = False
                elif losowa == 2 and self.get_x() != self._swiat.get_szerokosc() - 1:
                    nowe_x += 1
                    wychodzizamape = False
                elif losowa == 3 and self.get_x() != 0:
                    nowe_x -= 1
                    wychodzizamape = False

            if self._swiat.czy_pole_puste(nowe_x, nowe_y):
                self.set_x(nowe_x)
                self.set_y(nowe_y)
            else:
                organizm = self._swiat.get_organizm(nowe_x, nowe_y)
                if organizm and not organizm.czy_odbil_atak(self):
                    self.set_x(nowe_x)
                    self.set_y(nowe_y)
                    organizm.kolizja(self)

    def czy_odbil_atak(self, atakujacy):
        if atakujacy.get_sila() < 5:
            print("Atak Odbity")
            return True
        return False

    def rysowanie(self, canvas, cell_width, cell_height):
        font_size = min(max(min(cell_width, cell_height) - 6, 10), 30)
        canvas.create_text(self.get_x() * cell_width + cell_width // 2,
                           self.get_y() * cell_height + cell_height // 2,
                           text="\U0001F422",  # Emoji żółwia
                           font=("Segoe UI Emoji", font_size),
                           fill="green")  # Dark Green

    def get_gatunek(self):
        return 'Z'

    def nowy_organizm(self, x, y, swiat):
        return Zolw(x, y, swiat)
