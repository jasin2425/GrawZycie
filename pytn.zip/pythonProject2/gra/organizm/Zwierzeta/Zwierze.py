import random
from gra.organizm.Organizm import Organizm

class Zwierze(Organizm):
    def __init__(self, x, y, swiat=None):
        super().__init__(x, y, swiat)

    def akcja(self):
        wychodzizamape = True
        nowe_x = self.get_x()
        nowe_y = self.get_y()
        rand = random.Random()

        while wychodzizamape:
            nowe_x = self.get_x()
            nowe_y = self.get_y()
            losowa = rand.randint(0, 3)

            if losowa == 0 and self.get_y() != 0:
                wychodzizamape = False
                nowe_y -= 1
            elif losowa == 1 and self.get_y() != self.get_swiat().get_wysokosc() - 1:
                wychodzizamape = False
                nowe_y += 1
            elif losowa == 2 and self.get_x() != self.get_swiat().get_szerokosc() - 1:
                wychodzizamape = False
                nowe_x += 1
            elif losowa == 3 and self.get_x() != 0:
                wychodzizamape = False
                nowe_x -= 1

        if self.get_swiat().czy_pole_puste(nowe_x, nowe_y) and not wychodzizamape:
            self.set_x(nowe_x)
            self.set_y(nowe_y)
        else:
            organizm = self.get_swiat().get_organizm(nowe_x, nowe_y)
            if not organizm.czy_odbil_atak(self):
                self.set_x(nowe_x)
                self.set_y(nowe_y)
                organizm.kolizja(self)

    def czy_odbil_atak(self, atakujacy):
        return False

    def rysowanie(self, g, cell_size):
        raise NotImplementedError("This method should be overridden by subclasses")

    def nowy_organizm(self, x, y, swiat):
        raise NotImplementedError("This method should be overridden by subclasses")

    def get_gatunek(self):
        raise NotImplementedError("This method should be overridden by subclasses")